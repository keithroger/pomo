package main

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-lambda-go/lambdacontext"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

const TableName = "pomo-study-user-stats"

type RequestDDB struct {
}

type ResponseDDB struct {
}

type Event struct {
	Name string `json:"name"`
}

func HandleRequest(ctx context.Context, name Event) (string, error) {
	date := "2021-05-09T12:10:00+01:00"
	layout := "2006-01-02T15:04:05-07:00"
	t, err := time.Parse(layout, date)

	if err != nil {
		fmt.Println(err)
	}
	fmt.Println(t)
	lc, _ := lambdacontext.FromContext(ctx)
	log.Print(lc.Identity.CognitoIdentityID)

	cfg, err := config.LoadDefaultConfig(context.TODO(), func(o *config.LoadOptions) error {
		o.Region = "us-west-1"
		return nil
	})

	if err != nil {
		panic(err)
	}

	svc := dynamodb.NewFromConfig(cfg)
	out, err := svc.Query(context.TODO(), &dynamodb.QueryInput{
		TableName:              aws.String("pomo-study-user-stats"),
		KeyConditionExpression: aws.String("id = :username"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":username": &types.AttributeValueMemberS{Value: "123"},
			":rangeKey": &types.AttributeValueMemberN{Value: "20150101"},
		},
		ExpressionAttributeNames: map[string]string{
			"#date": "date",
		},
	})
	if err != nil {
		panic(err)
	}

	fmt.Println(out.Items)

	return fmt.Sprintf("Hello %s!", name.Name), nil
}

func main() {
	lambda.Start(HandleRequest)
}
